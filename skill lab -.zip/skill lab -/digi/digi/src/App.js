import React from 'react';
// import Category from './category';
 import BookForm from './Admin/BookForm';




const App = () => {
  // const categories = ['Technology', 'Health', 'Education', 'Finance'];
  // const relevances = ['High', 'Medium', 'Low'];

  return (
    <div>
      {/* <Category categories={categories} relevances={relevances} /> */}
     
       <BookForm/>  
    
      
      
    </div>
  );
};

export default App;
