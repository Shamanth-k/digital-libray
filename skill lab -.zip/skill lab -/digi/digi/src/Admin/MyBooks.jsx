import React from 'react';

const MyBooks = () => {
  return (
    <div>
      <h1>My Books</h1>
    </div>
  );
};

export default MyBooks;
